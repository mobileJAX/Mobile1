package ac.kr.kumoh.testfacebook;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;

//import com.facebook.samples.hellofacebook.R;
//import com.facebook.samples.hellofacebook.HelloFacebookSampleActivity.PendingAction;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.FacebookDialog.PhotoShareDialogBuilder;
import com.facebook.widget.LoginButton;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton.UserInfoChangedCallback;

public class MainActivity extends Activity {

	private LoginButton loginBtn;
    private Button postImageBtn;
    private Button updateStatusBtn;
 
    private TextView userName;
    protected Bitmap pendingBitmap;
    
    private UiLifecycleHelper uiHelper;
 
    private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        uiHelper = new UiLifecycleHelper(this, statusCallback);
        uiHelper.onCreate(savedInstanceState);
 
        setContentView(R.layout.activity_main);
 
        userName = (TextView) findViewById(R.id.user_name);
        loginBtn = (LoginButton) findViewById(R.id.fb_login_button);
        loginBtn.setUserInfoChangedCallback(new UserInfoChangedCallback() {
            @Override
            public void onUserInfoFetched(GraphUser user) {
                if (user != null) {
                    userName.setText("Hello, " + user.getName());
                } else {
                    userName.setText("You are not logged");
                }
            }
        });
 
        postImageBtn = (Button) findViewById(R.id.post_image);
        postImageBtn.setOnClickListener(new OnClickListener() {
 
            @Override
            public void onClick(View view) {
                postImage();
            }
        });
 
        updateStatusBtn = (Button) findViewById(R.id.update_status);
        updateStatusBtn.setOnClickListener(new OnClickListener() {
 
            @Override
            public void onClick(View v) {
            	postStatusMessage();
            }
        });
 
       // buttonsEnabled(false);
    }
 
    private Session.StatusCallback statusCallback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state,
                Exception exception) {
            if (state.isOpened()) {
                buttonsEnabled(true);
                Log.d("FacebookSampleActivity", "Facebook session opened");
            } else if (state.isClosed()) {
                buttonsEnabled(false);
                Log.d("FacebookSampleActivity", "Facebook session closed");
            }
        }
    };
 
    
    public void buttonsEnabled(boolean isEnabled) {
        postImageBtn.setEnabled(isEnabled);
        updateStatusBtn.setEnabled(isEnabled);
    }
    
    private FacebookDialog.PhotoShareDialogBuilder createShareDialogBuilderForPhoto(Bitmap... photos) {
        return new FacebookDialog.PhotoShareDialogBuilder(this)
                .addPhotos(Arrays.asList(photos));
    }
 
    public void postImage() {
        if (checkPermissions()) {
            Bitmap pendingBitmap = BitmapFactory.decodeResource(getResources(),
                    R.drawable.ic_launcher);
        	FacebookDialog shareDialog = createShareDialogBuilderForPhoto(
                    pendingBitmap).build();
            uiHelper.trackPendingDialogCall(shareDialog.present());
        	} else {
            requestPermissions();
        }
    }
 
    private FacebookDialog.ShareDialogBuilder createShareDialogBuilderForLink() {
        return new FacebookDialog.ShareDialogBuilder(this)
                .setName("Mobile Test")
                .setDescription("�� ���� ����ϼ���Ʈ����������Ʈ ���� ��ǥ�� �Դϴ�.")
                .setLink("http://mobilekit.tistory.com");        
    }
    
    public void postStatusMessage() {
    	 if (checkPermissions()) {
         	FacebookDialog shareDialog = createShareDialogBuilderForLink().build();
             uiHelper.trackPendingDialogCall(shareDialog.present());
        } else {
            requestPermissions();
        }     
    }
 
    public boolean checkPermissions() {
        Session s = Session.getActiveSession();
        if (s != null) {
            return s.getPermissions().contains("publish_actions");
        } else
            return false;
    }
 
    public void requestPermissions() {
        Session s = Session.getActiveSession();
        if (s != null)
            s.requestNewPublishPermissions(new Session.NewPermissionsRequest(
                    this, PERMISSIONS));
    }
 
    @Override
    public void onResume() {
        super.onResume();
        uiHelper.onResume();
        //buttonsEnabled(Session.getActiveSession().isOpened());
    }
 
    @Override
    public void onPause() {
        super.onPause();
        uiHelper.onPause();
    }
 
    @Override
    public void onDestroy() {
        super.onDestroy();
        uiHelper.onDestroy();
    }
 
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uiHelper.onActivityResult(requestCode, resultCode, data);
    }
 
    @Override
    public void onSaveInstanceState(Bundle savedState) {
        super.onSaveInstanceState(savedState);
        uiHelper.onSaveInstanceState(savedState);
    }

}
