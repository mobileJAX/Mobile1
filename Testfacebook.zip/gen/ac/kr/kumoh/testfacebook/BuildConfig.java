/** Automatically generated file. DO NOT MODIFY */
package ac.kr.kumoh.testfacebook;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}